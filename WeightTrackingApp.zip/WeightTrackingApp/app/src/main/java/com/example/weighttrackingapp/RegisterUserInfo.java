package com.example.weighttrackingapp;

import android.os.Bundle;
import android.widget.EditText;
import android.widget.Button;
import android.widget.Toast;
import android.database.sqlite.SQLiteDatabase;
import android.database.Cursor;
import androidx.appcompat.app.AppCompatActivity;

public class RegisterUserInfo extends AppCompatActivity {

    Button RegisterUserButton;
    EditText UsernameHolder, PasswordHolder, CellNumberHolder;
    UsersSQLite handler;
    Boolean EmptyHolder;
    SQLiteDatabase db;
    String Result = "Nothing Found";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        UsernameHolder = findViewById(R.id.editTextUserName);
        PasswordHolder = findViewById(R.id.editTextPassword);
        CellNumberHolder = findViewById(R.id.editTextCellNumber);
        handler = new UsersSQLite(this);

        RegisterUserButton.setOnClickListener(view -> {
            String message = CheckEditTextIfEmpty();

            if (!EmptyHolder) {
                CheckIfUsernameExists();
                EmptyEditTextPostNewInfo();
            } else {
                Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
            }
        });
    }

    // Now to register a new user's info to the db

    public String AddNewUserToDB() {

        String message = "";
        String Username = UsernameHolder.getText().toString().trim();
        String Password = PasswordHolder.getText().toString().trim();
        String cellNumber = CellNumberHolder.getText().toString().trim();

        // Any empty fields?

        if (Username.isEmpty()) {
            UsernameHolder.requestFocus();
            EmptyHolder = true;
            message = "Please enter a user name";
        } else if (Password.isEmpty()) {
            PasswordHolder.requestFocus();
            EmptyHolder = true;
            message = "Please enter a password";
        } else if (cellNumber.isEmpty()) {
            CellNumberHolder.requestFocus();
            EmptyHolder = true;
            message = "Please enter a phone number";

        else{
                EmptyHolder = false;
            }

            return message;
        }

        // Does Username already exist?

        public void CheckIfUsernameExists () {
            String username = UsernameHolder.getText().toString().trim();
            db = handler.getWritableDatabase();


            Cursor cursor = db.query(UsersSQLite.TABLE_NAME, null, " " + UsersSQLite.COLUMN_1_USERNAME + "=?", new String[]{username}, null, null, null);

            while (cursor.moveToNext()) {
                if (cursor.isFirst()) {
                    cursor.moveToFirst();

                    //Username found here
                    Result = "Username found!";
                    cursor.close();
                }
            }
            handler.close();

            CheckCredentialsEnd();
        }

        public void CheckCredentialsEnd () {

            if (Result.equalsIgnoreCase("Username Found")) {

                Toast.makeText(RegisterUserInfo.this, "Username already exists, please try logging in again", Toast.LENGTH_LONG).show();
            } else {
                // enter user information into the database and register the user
                AddNewUserToDB();
            }

            Result = "Not Found!";
        }

        public void EmptyEditTextPostNewInfo() {
            UsernameHolder.getText().clear();
            PasswordHolder.getText().clear();
            CellNumberHolder.getText().clear();
        }
    }

}
