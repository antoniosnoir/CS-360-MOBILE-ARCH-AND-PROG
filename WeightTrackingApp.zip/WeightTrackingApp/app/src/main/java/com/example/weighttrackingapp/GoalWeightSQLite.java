package com.example.weighttrackingapp;

import android.database.sqlite.SQLiteOpenHelper;
import android.database.sqlite.SQLiteDatabase;
import android.content.Context;
import android.content.ContentValues;
import android.database.Cursor;

import java.util.Objects;
import java.util.List;
import java.util.ArrayList;

import com.example.weighttrackingapp.GoalWeight;

public class GoalWeightSQLite extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "GoalWeight.DB";
    public static final String TABLE_NAME = "GoalWeightTable";
    public static final String COLUMN_0_GOALWEIGHT = "goal_weight";
    private static final int DATABASE_VERSION =1;
    private static final String CREATE_GOALWEIGHT_TABLE = "CREATE TABLE IF NOT EXISTS " + TABLE_NAME + " (" + COLUMN_0_GOALWEIGHT + " " + ");";

    public GoalWeightSQLite(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase database) {
        database.execSQL(CREATE_GOALWEIGHT_TABLE);
    }

    @Override
    public void onUpgrade(GoalWeightSQLite db, int previousVersion, int upgradedVersion) {
        db.execSQL("DROP TABLE IF EXISTS" + TABLE_NAME);
        onCreate(db);
    }

    // Add goal weight to database
    public void createGoalWeight(GoalWeight goalweight) {
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(COLUMN_0_GOALWEIGHT, goalweight.getUserGoalWeight());

        db.insert(TABLE_NAME, null, values);
        db.close();
    }

    // Read goal weight from database
    public GoalWeight readGoalWeight(int id) {
        SQLiteDatabase db = this.getReadableDatabase();

        Cursor cursor = db.query(TABLE_NAME, new String[]{COLUMN_0_GOALWEIGHT}, COLUMN_0_GOALWEIGHT + "=?", new String[]{String.valueOf(id)}, null, null, null);

        if(cursor != null)
            cursor.moveToFirst();

        GoalWeight goalWeight = new GoalWeight(Integer.parseInt(Objects.requireNonNull(cursor).getString(0));

        cursor.close();

        return goalWeight;
    }

    // Now, to update the goal weight in the database
    public int updateGoalWeight(GoalWeight goalWeight) {

        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(COLUMN_0_GOALWEIGHT, goalWeight.getUserGoalWeight());

        return db.update(TABLE_NAME, values, COLUMN_0_GOALWEIGHT + "=?", new String[]{String.valueOf(goalWeight.getUserGoalWeight())});
    }

    // Delete goal weight from the database
    public void deleteItem(GoalWeight goalWeight) {
        SQLiteDatabase db = this.getWritableDatabase();

        db.delete(TABLE_NAME, COLUMN_0_GOALWEIGHT + "=?", new String[]{String.valueOf(goalWeight.getId())});
        db.close();
    }
}


