package com.example.weighttrackingapp;

import android.os.Bundle;
import android.telephony.SmsManager;
import android.widget.ListView;
import android.widget.ImageButton;
import android.widget.Toast;
import android.Manifest;
import android.content.pm.PackageManager;
import android.content.Intent;
import android.content.Context;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AlertDialog;
import androidx.core.content.ContextCompat;
import androidx.core.app.ActivityCompat;

import com.example.weighttrackingapp.DailyWeights;
import com.example.weighttrackingapp.DailyWeightsSQLite;
import com.example.weighttrackingapp.LogInInfo;
import com.example.weighttrackingapp.R;
import com.example.weighttrackingapp.SMSMessaging;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    public static final String UserWeight = "";
    private static final int SEND_SMS = 0;
    private static boolean smsAuthorization = false;
    static String UsernameHolder, PasswordHolder, PhoneNumberHolder;
    ImageButton buttonAddWeight, buttonSMS;

    ArrayList<DailyWeights> weightsOfDay;
    DailyWeightsSQLite db;
    ListView weightListView;
    AlertDialog AlertDialog = null;
    int weightsAdded;
    MyWeightsList myWeightsList;

    public static void AcceptSMS(){
        smsAuthorization = true;
    }

    public static void RejectSMS() {
        smsAuthorization = false;
    }

    public static void OutgoingSMS(Context context) {
        String cellNumber = PhoneNumberHolder;
        String SMSInfo = "Congrats! You've reached your goal weight!";

        if(smsAuthorization) {
            try {
                SmsManager smsManager = SmsManager.getDefault();
                smsManager.sendTextMessage(cellNumber, null, SMSInfo, null, null);
                Toast.makeText(context, "Message has been sent", Toast.LENGTH_LONG).show();
            } catch (Exception ex) {
                Toast.makeText(context, "SMS not authorized", Toast.LENGTH_LONG).show();
                ex.printStackTrace();
            }
        }

        else {
                Toast.makeText(context, "SMS notification has been disabled", Toast.LENGTH_LONG).show();
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.mainActivity);

        buttonAddWeight = findViewById(R.id.buttonAddWeight);
        buttonSMS = findViewById(R.id.buttonSMS);
        weightListView = findViewById(R.id.buttonListView);
        db = new DailyWeightsSQLite(this);

        Bundle bundle = getIntent().getExtras();
        if (bundle != null) {
            UsernameHolder = bundle.getString("userUserName");
            PasswordHolder = bundle.getString("userPassword");
            PhoneNumberHolder = bundle.getString("userPhoneNumber");
        }

        weightsOfDay = (ArrayList<DailyWeights>) db.getAllWeights();

        weightsAdded = db.getWeightsAdded();

        if (weightsAdded > 0) {
            myWeightsList = new MyWeightsList(this, weightsOfDay, db);
            weightListView.setAdapter(myWeightsList);
        }
        else {
            Toast.makeText(this, "Nothing in database", Toast.LENGTH_LONG).show();
        }

        buttonAddWeight.setOnClickListener(view -> {

            Intent add = new Intent(this, AddWeight.class);
            add.putExtra(userWeight, WeightHolder);
            startActivityForResult(add, 1);
        });

        buttonSMS.setOnClickListener(view -> {

            if(ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS) != PackageManager.PERMISSION_GRANTED) {

                if (ActivityCompat.shouldShowRequestPermissionRationale(this, Manifest.permission.SEND_SMS)) {
                    Toast.makeText(this, "Please authorize SMS", Toast.LENGTH_LONG).show();
                } else {
                    ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.SEND_SMS}, USER_AUTHORIZATION_SEND_SMS);
                }

                } else {
                    Toast.makeText(this, "You have authorized SMS", Toast.LENGTH_LONG).show();
                }

                AlertDialog = AlertSMSNotification.doubleButton(this);
                AlertDialog.show();

        });

    }



  @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
}