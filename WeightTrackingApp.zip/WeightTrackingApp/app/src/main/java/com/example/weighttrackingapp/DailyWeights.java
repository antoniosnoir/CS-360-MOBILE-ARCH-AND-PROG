package com.example.weighttrackingapp;

public class DailyWeights {

    int id;
    String user_WeightDate;
    String user_weightAmount;

    public DailyWeights() {
        super();
    }

    public DailyWeights(int i, String date, String weight) {
        super();
        this.id = i;
        this.user_WeightDate = date;
        this.user_weightAmount = weight;
    }

    public DailyWeights(String date, String weight) {
        this.user_WeightDate = date;
        this.user_weightAmount = weight;
    }

    public int getID() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getWeightDate() {
        return user_WeightDate;
    }

    public void setWeightDate(String date) {
        this.user_WeightDate = date;
    }

    public String getWeightAmount() {
        return user_weightAmount;
    }

    public void setWeightAmount(String weight) {
        this.user_weightAmount = weight;
    }
}
