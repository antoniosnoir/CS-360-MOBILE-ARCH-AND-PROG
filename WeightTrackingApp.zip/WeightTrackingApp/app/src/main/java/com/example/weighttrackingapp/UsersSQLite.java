package com.example.weighttrackingapp;

import android.database.sqlite.SQLiteOpenHelper;
import android.database.sqlite.SQLiteDatabase;
import android.content.Context;
import android.content.ContentValues;
import android.database.Cursor;
import com.example.weighttrackingapp.User;

import java.util.List;
import java.util.ArrayList;
import java.util.Objects;

public class UsersSQLite extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "UsersData.DB";
    public static final String TABLE_NAME = "UsersDataTable";
    public static final String COLUMN_0_ID = "id";
    public static final String COLUMN_1_USERNAME = "username";
    public static final String COLUMN_2_PASSWORD = "password";
    public static final String COLUMN_3_CELLNUMBER = "cellphonenumber";

    private static final int DATABASE_VERSION = 1;
    private static final String CREATE_USERS_TABLE = "CREATE TABLE IF NOT EXISTS " + TABLE_NAME + " ( " + COLUMN_0_ID  + " " +
            COLUMN_1_USERNAME + " " + COLUMN_2_PASSWORD + " " + COLUMN_3_CELLNUMBER + "); ";

    public UsersSQLite(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase database) {
        database.execSQL(CREATE_USERS_TABLE);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int previousVersion, int updatedVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_NAME);
        onCreate(db);
    }

    // Users can be added to the database here
    public void createNewUser(User user) {
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(COLUMN_1_USERNAME, user.getUserName());
        values.put(COLUMN_2_PASSWORD, user.getPassword());
        values.put(COLUMN_3_CELLNUMBER, user.getCellNumber());

        db.insert(TABLE_NAME, null, values);
        db.close();
    }

    public User readUser(int id) {
        SQLiteDatabase db = this.getReadableDatabase();

        Cursor cursor = db.query(TABLE_NAME, new String[] {COLUMN_0_ID, COLUMN_1_USERNAME, COLUMN_2_PASSWORD, COLUMN_3_CELLNUMBER}, COLUMN_0_ID + " =? ",
                new String[]{String.valueOf(id)}, null, null, null, null);

        if (cursor != null)
            cursor.moveToFirst();

        User user = new User (Integer.parseInt(Objects.requireNonNull(cursor).getString(0)), cursor.getString(1), cursor.getString(2),
                cursor.getString(3));

        cursor.close();

        return user;
    }

    // Now, on to updating a user in the database
    public int updateUser(User user) {

        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(COLUMN_1_USERNAME, user.getUserName());
        values.put(COLUMN_2_PASSWORD, user.getPassword());
        values.put(COLUMN_3_CELLNUMBER, user.getCellNumber());

        return db.update(TABLE_NAME, values, COLUMN_0_ID + "=?", new String[] {String.valueOf(user.getId())});
    }

    // Now, to delete a user from the database
    public void deleteItem(User user) {
        SQLiteDatabase db = this.getWritableDatabase();

        db.delete(TABLE_NAME, COLUMN_0_ID + "=?", new String[] {String.valueOf(user.getId())});
        db.close();
    }

}
