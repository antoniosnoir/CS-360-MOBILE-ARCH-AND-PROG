package com.example.weighttrackingapp;

import android.app.Activity;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import android.widget.Toast;
import android.widget.EditText;
import android.widget.Button;

// Login Info (LogInInfo) stored here

public class LogInInfo extends AppCompatActivity {

    Activity activity;
    Button LoginButton, PasswordHelpButton /*REMOVE?*/, RegisterUserButton;
    EditText Username, Password, PhoneNumber;
    String UsernameHolder, PasswordHolder, PhoneNumberHolder;
    String TempPassword;
    SQLiteDatabase db;
    UsersSQLite handler;
    Boolean EmptyHolder;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        activity = this;

        LoginButton = findViewById(R.id.signinButton);
        RegisterUserButton = findViewById(R.id.registerButton);
        Username = findViewById(R.id.editTextUsername);
        Password = findViewById(R.id.editTextPassword);
        PhoneNumber = findViewById(R.id.editTextPhone);
        handler = new UsersSQLite(this);

        LoginButton.setOnClickListener(view -> {
            LoginFunction();
        });

        RegisterUserButton.setOnClickListener(view -> {
            Intent intent = new Intent(LogInInfo.this, RegisterUserInfo.class);
            startActivity(intent);
        });

    }
    {
                Toast.makeText(LogInInfo.this, "Username is empty, please enter a username" , Toast.LENGTH_LONG).show();
    }

    public void LoginFunction() {

        String message = CheckEditTextIfEmpty();
    }

    public String CheckEditTextIfEmpty() {
        String message = "";

        UsernameHolder = Username.getText().toString().trim();
        PasswordHolder = Password.getText().toString().trim();
        PhoneNumberHolder = PhoneNumber.getText().toString().trim();

        if(UsernameHolder.isEmpty()) {
            Username.requestFocus();
            EmptyHolder = true;
            message = "Please enter a username";
        }
        else if (PasswordHolder.isEmpty()) {
            Password.requestFocus();
            EmptyHolder = true;
            message = "Please enter a password";
        }

        else if (PhoneNumberHolder.isEmpty()) {
            Password.requestFocus();
            EmptyHolder = true;
            message = "Please enter a phone number";
        }
        else {
            EmptyHolder = false;
        }

        return message;

    }

    //the app should check password against database

    public void FinalResult() {
        if(TempPassword.equalsIgnoreCase(PasswordHolder)) {
            Toast.makeText(LogInInfo.this, "You are logged in", Toast.LENGTH_SHORT).show();

                  //after login, user should be taken to weights entered screen
                  Intent intent = new Intent(LogInInfo.this, DailyWeights.class);
                  intent.putExtras(bundle);
                  startActivity(intent);
                  this.finish();

                  //IMPORTANT: close database after logging in
                  EmptyEditTextPostLogIn();
                 }

                 else {

                     Toast.makeText(LogInInfo.this, "Wrong username or password, please enter again", Toast.LENGTH_LONG).show();
                 }

                 TempPassword = "NOTHING FOUND";
    }

    public void EmptyEditTextPostLogIn() {
        Username.getText().clear();
        Password.getText().clear();
        PhoneNumber.getText().clear();
    }
}


