package com.example.weighttrackingapp;

import android.widget.EditText;
import android.widget.Toast;
import android.widget.Button;
import android.os.Bundle;
import android.content.Intent;

import androidx.appcompat.app.AppCompatActivity;

import com.example.weighttrackingapp.DailyWeightsSQLite;
import com.example.weighttrackingapp.DailyWeights;
import com.example.weighttrackingapp.R;

import java.util.concurrent.atomic.AtomicReference;

public class AddWeight extends AppCompatActivity {

    String WeightHolder, DateHolder;
    EditText WeightValue, DateValue;
    Boolean EmptyHolder;
    Button AddWeightButton;
    DailyWeightsSQLite db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_addweight);

        WeightValue = findViewById(R.id.editTextEditWeight);
        DateValue = findViewById(R.id.editTextEditDate);
        AddWeightButton = findViewById(R.id.addWeightAddButton);
        db = new DailyWeightsSQLite(this);

        AtomicReference<Intent> intent = new AtomicReference<>(getIntent());

        WeightHolder = intent.get().getStringExtra(MainActivity.UserWeight);
    }

    public void InsertWeightIntoDB() {
        String message = CheckIfEditTextEmpty();

        if(!EmptyHolder) {
            String weight = WeightHolder;
            String date = DateHolder;

            DailyWeights dailyWeights = new DailyWeights(weight, date);
            db.createWeight(dailyWeights);

            Toast.makeText(this, "Daily weight had been added, good job!", Toast.LENGTH_LONG).show();

            Intent add = new Intent();
            setResult(RESULT_OK, add);
            this.finish();
        }

    }
}
