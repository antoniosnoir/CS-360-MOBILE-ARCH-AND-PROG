package com.example.weighttrackingapp;

public class User {

    int id;
    String user_userName;
    String user_userPassword;
    String user_userCellNumber;

    public User() {
        super();
    }

    public User(int i, String name, String password, String phoneNumber) {
        super();
        this.id = i;
        this.user_userName = name;
        this.user_userPassword = password;
        this.user_userCellNumber = phoneNumber;
    }

    public User(String name, String password, String phoneNumber) {
        this.user_userName = name;
        this.user_userPassword = password;
        this.user_userCellNumber = phoneNumber;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getUserName() {
        return user_userName;
    }

    public void setUser_userName(String name) {
        this.user_userName = name;
    }

    public String getPassword() {
        return user_userPassword;
    }

    public void setUser_userPassword(String password) {
        this.user_userPassword = password;
    }

    public String getCellNumber() {
        return user_userCellNumber;
    }

    public void setUser_userCellNumber(String phoneNumber) {
        this.user_userCellNumber = phoneNumber;
    }
}
