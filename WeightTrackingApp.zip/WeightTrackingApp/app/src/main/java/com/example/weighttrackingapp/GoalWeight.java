package com.example.weighttrackingapp;

import android.content.Context;

public class GoalWeight  {
    int id;
    String userGoalWeight;

    public GoalWeight() {
        super();
    }

    public GoalWeight(int i, String weightGoal) {

        super();
        this.id = i;
        this.userGoalWeight = weightGoal;
    }

    public GoalWeight(String weightGoal) {
        this.userGoalWeight = weightGoal;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getUserGoalWeight() {
        return userGoalWeight;
    }

    public void setUserGoalWeight(String userGoalWeight) {
        this.userGoalWeight = userGoalWeight;
    }
}
