package com.example.weighttrackingapp;

import android.widget.Toast;
import androidx.appcompat.app.AlertDialog;
import com.example.weighttrackingapp.R;
import com.example.weighttrackingapp.GoalWeightSQLite;

public class SMSMessaging {

    public static AlertDialog doubleButton(final GoalWeight context) {
        AlertDialog.Builder builder  = new AlertDialog.Builder(context);
        builder.setTitle(R.string.alert_sms_title)
                .setMessage(R.string.alert_sms_msg)
                .setIcon(R.drawable.button_sms)
                .setCancelable(false)
                .setPositiveButton(R.string.alert_sms_enabled_button, (dialog, arg1) ->
                {
                    Toast.makeText(context, "You have opted to receive SMS notifications", Toast.LENGTH_LONG).show();
                    GoalWeight.AllowSendSMS();
                    dialog.cancel();
                })
                .setNegativeButton(R.string.alert_sms_disable_button, (dialog, arg1) ->
                {
                    Toast.makeText(context, "You will not receive SMS notifications", Toast.LENGTH_LONG).show();
                    GoalWeight.DenySendSMS();
                    dialog.cancel();
                });

        return builder.create();
    }
}
